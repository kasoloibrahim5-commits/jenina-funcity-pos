import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { Pool } from "pg";

dotenv.config();
const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const JWT_SECRET = process.env.JWT_SECRET || "development-only-secret";

app.use(cors());
app.use(express.json());

function auth(req: any, res: any, next: any) {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (!token) return res.status(401).json({success:false,error:"AUTH_REQUIRED"});
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { return res.status(401).json({success:false,error:"INVALID_TOKEN"}); }
}

function receiptNumber() {
  const d = new Date();
  const stamp = d.toISOString().replace(/[-:TZ.]/g,"").slice(0,14);
  return `JF-${stamp}-${Math.floor(Math.random()*900+100)}`;
}

app.get("/api/v1/health", async (_req,res) => {
  try { await pool.query("SELECT 1"); res.json({success:true,database:"ok"}); }
  catch { res.status(503).json({success:false,error:"DATABASE_UNAVAILABLE"}); }
});

app.post("/api/v1/auth/register", async (req,res) => {
  const {fullName, username, password, role="CASHIER"} = req.body;
  if (!fullName || !username || !password) return res.status(400).json({success:false,error:"VALIDATION_ERROR"});
  const hash = await bcrypt.hash(password, 12);
  try {
    const r = await pool.query(
      "INSERT INTO users(full_name,username,password_hash,role) VALUES($1,$2,$3,$4) RETURNING id,full_name,username,role",
      [fullName,username,hash,role]
    );
    res.status(201).json({success:true,data:r.rows[0]});
  } catch { res.status(409).json({success:false,error:"USERNAME_EXISTS"}); }
});

app.post("/api/v1/auth/login", async (req,res) => {
  const {username,password} = req.body;
  const r = await pool.query("SELECT * FROM users WHERE username=$1 AND active=true",[username]);
  if (!r.rows[0] || !(await bcrypt.compare(password,r.rows[0].password_hash)))
    return res.status(401).json({success:false,error:"INVALID_CREDENTIALS"});
  const user = r.rows[0];
  const token = jwt.sign({id:user.id,username:user.username,role:user.role},JWT_SECRET,{expiresIn:"8h"});
  res.json({success:true,token,user:{id:user.id,fullName:user.full_name,username:user.username,role:user.role}});
});

app.get("/api/v1/counters", auth, async (_req,res) => {
  const r=await pool.query("SELECT * FROM counters WHERE active=true ORDER BY name");
  res.json({success:true,data:r.rows});
});

app.get("/api/v1/products", auth, async (req,res) => {
  const department=String(req.query.department||"");
  const sql=department
    ? "SELECT p.*,c.department FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.active=true AND c.department=$1 ORDER BY p.name"
    : "SELECT p.*,c.department FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.active=true ORDER BY p.name";
  const r=await pool.query(sql,department?[department]:[]);
  res.json({success:true,data:r.rows});
});

app.post("/api/v1/sales", auth, async (req:any,res) => {
  const {counterId,items,discount=0,paymentMethod,paymentAmount,phoneNumber} = req.body;
  if(!counterId || !Array.isArray(items) || !items.length) return res.status(400).json({success:false,error:"INVALID_SALE"});
  const client=await pool.connect();
  try {
    await client.query("BEGIN");
    let subtotal=0;
    for(const item of items) subtotal += Number(item.quantity)*Number(item.unitPrice);
    const total=Math.max(0,subtotal-Number(discount));
    if(Number(paymentAmount ?? total) < total) throw new Error("INSUFFICIENT_PAYMENT");

    const sale=await client.query(
      "INSERT INTO sales(receipt_number,counter_id,cashier_id,subtotal,discount_amount,total_amount,status) VALUES($1,$2,$3,$4,$5,$6,'PAID') RETURNING *",
      [receiptNumber(),counterId,req.user.id,subtotal,discount,total]
    );
    for(const item of items) {
      await client.query(
        "INSERT INTO sale_items(sale_id,product_id,quantity,unit_price,total_amount) VALUES($1,$2,$3,$4,$5)",
        [sale.rows[0].id,item.productId,item.quantity,item.unitPrice,Number(item.quantity)*Number(item.unitPrice)]
      );
      const stock=await client.query("SELECT quantity FROM inventory_stock WHERE product_id=$1 FOR UPDATE",[item.productId]);
      if(stock.rows[0]) {
        if(Number(stock.rows[0].quantity)<Number(item.quantity)) throw new Error("INSUFFICIENT_STOCK");
        await client.query("UPDATE inventory_stock SET quantity=quantity-$1 WHERE product_id=$2",[item.quantity,item.productId]);
        await client.query("INSERT INTO stock_movements(product_id,movement_type,quantity,reference_type,reference_id,performed_by) VALUES($1,'SALE',$2,'SALE',$3,$4)",
          [item.productId,item.quantity,sale.rows[0].id,req.user.id]);
      }
    }
    await client.query(
      "INSERT INTO payments(sale_id,payment_method,amount,status,phone_number) VALUES($1,$2,$3,'SUCCESS',$4)",
      [sale.rows[0].id,paymentMethod||"CASH",paymentAmount??total,phoneNumber||null]
    );
    await client.query("INSERT INTO audit_logs(user_id,action,entity_type,entity_id,details) VALUES($1,'SALE_CREATED','SALE',$2,$3)",
      [req.user.id,sale.rows[0].id,JSON.stringify({total,paymentMethod})]);
    await client.query("COMMIT");
    res.status(201).json({success:true,data:sale.rows[0]});
  } catch(e:any) {
    await client.query("ROLLBACK");
    res.status(400).json({success:false,error:e.message||"SALE_FAILED"});
  } finally { client.release(); }
});

app.get("/api/v1/sales/:id", auth, async (req,res) => {
  const sale=await pool.query("SELECT * FROM sales WHERE id=$1",[req.params.id]);
  if(!sale.rows[0]) return res.status(404).json({success:false,error:"NOT_FOUND"});
  const items=await pool.query("SELECT si.*,p.name FROM sale_items si JOIN products p ON p.id=si.product_id WHERE sale_id=$1",[req.params.id]);
  const payments=await pool.query("SELECT * FROM payments WHERE sale_id=$1",[req.params.id]);
  res.json({success:true,data:{...sale.rows[0],items:items.rows,payments:payments.rows}});
});

app.get("/api/v1/dashboard/today", auth, async (_req,res) => {
  const sales=await pool.query("SELECT COALESCE(SUM(total_amount),0) total_sales,COUNT(*) transactions FROM sales WHERE status='PAID' AND created_at::date=CURRENT_DATE");
  const payments=await pool.query("SELECT payment_method,COALESCE(SUM(amount),0) amount FROM payments WHERE status='SUCCESS' AND created_at::date=CURRENT_DATE GROUP BY payment_method");
  res.json({success:true,data:{sales:sales.rows[0],payments:payments.rows}});
});

app.post("/api/v1/shifts/open", auth, async (req:any,res) => {
  const {counterId,openingCash=0}=req.body;
  const r=await pool.query("INSERT INTO cashier_shifts(user_id,counter_id,opening_cash) VALUES($1,$2,$3) RETURNING *",[req.user.id,counterId,openingCash]);
  res.status(201).json({success:true,data:r.rows[0]});
});

app.post("/api/v1/shifts/:id/close", auth, async (req,res) => {
  const {actualCash}=req.body;
  const r=await pool.query(`
    UPDATE cashier_shifts s SET actual_cash=$1,
    expected_cash=s.opening_cash+COALESCE((SELECT SUM(p.amount) FROM payments p JOIN sales x ON x.id=p.sale_id WHERE x.cashier_id=s.user_id AND p.payment_method='CASH' AND p.status='SUCCESS' AND p.created_at>=s.opened_at),0),
    cash_difference=$1-(s.opening_cash+COALESCE((SELECT SUM(p.amount) FROM payments p JOIN sales x ON x.id=p.sale_id WHERE x.cashier_id=s.user_id AND p.payment_method='CASH' AND p.status='SUCCESS' AND p.created_at>=s.opened_at),0)),
    status='CLOSED',closed_at=NOW() WHERE s.id=$2 RETURNING *`,[actualCash,req.params.id]);
  res.json({success:true,data:r.rows[0]});
});

app.get("/api/v1/pool/tables", auth, async (_req,res) => {
  const r=await pool.query("SELECT * FROM pool_tables ORDER BY table_number");
  res.json({success:true,data:r.rows});
});

app.post("/api/v1/pool/sessions", auth, async (req,res) => {
  const {poolTableId,customerName}=req.body;
  await pool.query("UPDATE pool_tables SET status='OCCUPIED' WHERE id=$1",[poolTableId]);
  const r=await pool.query("INSERT INTO pool_sessions(pool_table_id,customer_name) VALUES($1,$2) RETURNING *",[poolTableId,customerName||null]);
  res.status(201).json({success:true,data:r.rows[0]});
});

app.post("/api/v1/pool/sessions/:id/stop", auth, async (req,res) => {
  const s=await pool.query("SELECT ps.*,pt.hourly_rate FROM pool_sessions ps JOIN pool_tables pt ON pt.id=ps.pool_table_id WHERE ps.id=$1",[req.params.id]);
  if(!s.rows[0]) return res.status(404).json({success:false,error:"NOT_FOUND"});
  const row=s.rows[0], start=new Date(row.started_at).getTime(), end=Date.now();
  const minutes=Math.max(1,Math.ceil((end-start)/60000));
  const amount=Math.ceil(minutes/60*Number(row.hourly_rate));
  const r=await pool.query("UPDATE pool_sessions SET ended_at=NOW(),total_minutes=$1,amount=$2,status='COMPLETED' WHERE id=$3 RETURNING *",[minutes,amount,req.params.id]);
  await pool.query("UPDATE pool_tables SET status='AVAILABLE' WHERE id=$1",[row.pool_table_id]);
  res.json({success:true,data:r.rows[0]});
});

app.listen(Number(process.env.PORT||4000),()=>console.log("Jenina POS V2 API running"));
