# Jenina Funcity POS — Version 2

A database-backed starter POS for Jenina Funcity.

## V2 features
- PostgreSQL persistence
- JWT-style login starter
- Role-based authorization starter
- Four counters
- Product catalogue
- Real sales creation
- Payment recording
- Receipt lookup
- Inventory stock and movements
- Cashier shifts
- Dashboard summary
- Pool table sessions
- Steam/Sauna sessions
- Bar tabs
- Audit log table

## Quick start
1. Copy `.env.example` to `.env`.
2. Run `docker compose up -d db`.
3. Apply `database/schema.sql` to PostgreSQL.
4. In `backend`, run `npm install`, then `npm run dev`.
5. In `frontend`, run `npm install`, then `npm run dev`.

This is a development foundation. Before production, add secure authentication, migrations, validation, tests, HTTPS, backups, and real payment-provider integrations.
