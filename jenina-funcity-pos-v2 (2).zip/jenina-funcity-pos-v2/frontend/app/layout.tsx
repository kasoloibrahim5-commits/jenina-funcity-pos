import React from "react";
export default function RootLayout({children}:{children:React.ReactNode}) {
 return <html lang="en"><body style={{margin:0,fontFamily:"Arial,sans-serif",background:"#f4f4f4"}}>{children}</body></html>;
}
