"use client";
import {useEffect,useState} from "react";

const API=process.env.NEXT_PUBLIC_API_URL||"http://localhost:4000/api/v1";

type Counter={id:string;name:string;counter_type:string};
type Product={id:string;name:string;price:number;department:string};

export default function Home(){
 const [token,setToken]=useState("");
 const [username,setUsername]=useState("manager");
 const [password,setPassword]=useState("password");
 const [logged,setLogged]=useState(false);
 const [counters,setCounters]=useState<Counter[]>([]);
 const [counter,setCounter]=useState<Counter|null>(null);
 const [products,setProducts]=useState<Product[]>([]);
 const [cart,setCart]=useState<Product[]>([]);
 const [payment,setPayment]=useState("CASH");
 const [message,setMessage]=useState("");

 async function login(){
  const r=await fetch(`${API}/auth/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username,password})});
  const j=await r.json();
  if(!j.success){setMessage("Login failed. Create a user through the API first.");return}
  setToken(j.token);setLogged(true);
  const c=await fetch(`${API}/counters`,{headers:{Authorization:`Bearer ${j.token}`}});
  const cj=await c.json();setCounters(cj.data||[]);setCounter(cj.data?.[0]||null);
 }
 useEffect(()=>{if(!token||!counter)return;
  fetch(`${API}/products?department=${counter.counter_type}`,{headers:{Authorization:`Bearer ${token}`}})
   .then(r=>r.json()).then(j=>setProducts(j.data||[]));
 },[token,counter]);

 async function checkout(){
  if(!counter||!cart.length)return;
  const r=await fetch(`${API}/sales`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${token}`},
   body:JSON.stringify({counterId:counter.id,items:cart.map(p=>({productId:p.id,quantity:1,unitPrice:Number(p.price)})),paymentMethod:payment})});
  const j=await r.json();setMessage(j.success?`Sale completed: ${j.data.receipt_number}`:`Sale failed: ${j.error}`);if(j.success)setCart([]);
 }
 if(!logged)return <main style={{maxWidth:420,margin:"80px auto",background:"#fff",padding:30,borderRadius:12}}>
  <h1>JENINA FUNCITY</h1><p>POS Login</p>
  <input value={username} onChange={e=>setUsername(e.target.value)} placeholder="Username" style={{width:"100%",padding:12,marginBottom:10}}/>
  <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" style={{width:"100%",padding:12,marginBottom:10}}/>
  <button onClick={login} style={{width:"100%",padding:14}}>Login</button><p>{message}</p>
 </main>;

 const total=cart.reduce((s,p)=>s+Number(p.price),0);
 return <main>
  <header style={{background:"#111",color:"#fff",padding:20}}><h1 style={{margin:0}}>JENINA FUNCITY POS V2</h1><small>Nansana West II Zone, Gganda Road · UGX</small></header>
  <div style={{padding:20,display:"grid",gridTemplateColumns:"1fr 350px",gap:20}}>
   <section><h2>Counter</h2><div style={{display:"flex",gap:8,flexWrap:"wrap"}}>{counters.map(c=><button key={c.id} onClick={()=>{setCounter(c);setCart([])}}>{c.name}</button>)}</div>
   <h2>{counter?.name}</h2><div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>{products.map(p=><button key={p.id} onClick={()=>setCart([...cart,p])} style={{padding:18,background:"#fff",border:"1px solid #ddd"}}><b>{p.name}</b><br/>UGX {Number(p.price).toLocaleString()}</button>)}</div></section>
   <aside style={{background:"#fff",padding:20,borderRadius:10}}><h2>Order</h2>{cart.map((p,i)=><div key={i}>{p.name} — UGX {Number(p.price).toLocaleString()}</div>)}<hr/><h2>UGX {total.toLocaleString()}</h2>
   <select value={payment} onChange={e=>setPayment(e.target.value)} style={{width:"100%",padding:12}}><option>CASH</option><option>MTN_MOMO</option><option>AIRTEL_MONEY</option><option>CARD</option></select>
   <button onClick={checkout} style={{width:"100%",padding:15,marginTop:12}}>Complete Sale</button><p>{message}</p></aside>
  </div>
 </main>
}
