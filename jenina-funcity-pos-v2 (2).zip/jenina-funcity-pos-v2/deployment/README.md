# V2 deployment

Development:
- PostgreSQL via Docker Compose
- Backend on Node.js
- Frontend on Next.js

Production recommendation:
- Managed PostgreSQL
- Backend on a managed Node.js service or VPS
- Frontend on Vercel or equivalent
- HTTPS enabled
- Secrets stored as platform environment variables

Before production:
- Add database migrations
- Add strict request validation
- Add refresh-token authentication
- Add CSRF/rate limiting where applicable
- Add tests and monitoring
- Replace demo payment recording with real provider APIs
- Configure MTN MoMo and Airtel Money webhooks
- Configure card provider
